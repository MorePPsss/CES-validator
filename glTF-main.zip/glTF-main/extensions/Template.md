<!--
Copyright 2015-2021 The Khronos Group Inc.
SPDX-License-Identifier: CC-BY-4.0
-->

# TODO_EXTENSION_NAME

## Contributors

* TODO: Name, affiliation, and contact info for each contributor

## Status

TODO: Draft or Stable

## Dependencies

Written against the glTF 2.0 spec.

## Overview

TODO

## glTF Schema Updates

TODO

### JSON Schema

TODO: Links to the JSON schema for the new extension properties.

## Known Implementations

* TODO: List of known implementations, with links to each if available.

## Resources

* TODO: Resources, if any.
